lista_taxas = ['0.1970',
               '0.1806',
               '0.1589',
               '25.5105',
               '0.1810',
               '0.2639',
               '0.2777']

lista_moedas = ['Dólar Americano',
                'Euro',
                'Libra Esterlina',
                'Iene Japonês',
                'Franco Suíço',
                'Dólar Canadense',
                'Dólar Australiano']

lista_cifroes = ['US$',
                 '€',
                 '£',
                 '¥',
                 'CHF',
                 '$',
                 '$']
